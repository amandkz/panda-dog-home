// index.js
import Head from 'next/head';

export default function Home() {
  return (
    <>
      <Head>
        <title>Panda Dog Home</title>
        <meta charSet="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link
          href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap"
          rel="stylesheet"
        />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        />
      </Head>

      <header>
        <h1>Panda Dog Home</h1>
        <p>Hospedagem Caseira para Cães</p>
      </header>

      <section className="services">
        <h2><i className="fa-solid fa-dog"></i> Serviços</h2>
        <ul>
          <li>Hospedagem</li>
          <li>Dog Walker</li>
        </ul>
      </section>

      <section className="galeria">
        <h2>Nossos Hóspedes</h2>
        <div className="galeria-cards">
          <div className="card">
            <img src="/imagens/dog1.jpg" alt="Cachorro feliz" />
            <p>Jomero descansando</p>
          </div>
          <div className="card">
            <img src="/imagens/dog2.jpg" alt="Dog observando" />
            <p>Jomero observando</p>
          </div>
          <div className="card">
            <img src="/imagens/dog3.jpg" alt="Três cães" />
            <p>Da esquerda para direita: Bellinha, Jomero e Bernardo</p>
          </div>
        </div>
      </section>

      <section className="contact">
        <h2>Contato</h2>
        <div className="whatsapp-wrapper">
          <a
            href="https://wa.me/5511960613045"
            className="whatsapp-button"
            target="_blank"
            rel="noopener noreferrer"
          >
            <i className="fab fa-whatsapp"></i> Fale com a gente no WhatsApp
          </a>
        </div>
      </section>

      <a
        href="https://wa.me/5511960613045"
        className="whatsapp-float"
        target="_blank"
        rel="noopener noreferrer"
      >
        <i className="fab fa-whatsapp"></i>
      </a>

      <footer>
        <p>&copy; 2025 Panda Dog Home — Todos os direitos reservados.</p>
      </footer>
    </>
  );
}